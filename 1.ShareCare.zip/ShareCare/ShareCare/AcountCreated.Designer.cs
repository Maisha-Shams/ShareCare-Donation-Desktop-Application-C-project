﻿
namespace ShareCare
{
    partial class AcountCreated
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.sHARECAREDataSet = new ShareCare.SHARECAREDataSet();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.accountLastname = new System.Windows.Forms.Label();
            this.uSERSBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.accountFirstname = new System.Windows.Forms.Label();
            this.accountUsername = new System.Windows.Forms.Label();
            this.profileLastname = new System.Windows.Forms.Label();
            this.profileFirstname = new System.Windows.Forms.Label();
            this.profileUsername = new System.Windows.Forms.Label();
            this.lastname = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.uSERSTableAdapter1 = new ShareCare.SHARECAREDataSet3TableAdapters.USERSTableAdapter();
            this.userName = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.user = new System.Windows.Forms.Label();
            this.uSERSTableAdapter = new ShareCare.SHARECAREDataSetTableAdapters.USERSTableAdapter();
            this.sHARECAREDataSet3 = new ShareCare.SHARECAREDataSet3();
            this.uSERSBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.firstname = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.uSERSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.sHARECAREDataSet)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSERSBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sHARECAREDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSERSBindingSource2)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uSERSBindingSource)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // sHARECAREDataSet
            // 
            this.sHARECAREDataSet.DataSetName = "SHARECAREDataSet";
            this.sHARECAREDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Location = new System.Drawing.Point(-28, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1249, 63);
            this.panel1.TabIndex = 90;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox7.Image = global::ShareCare.Properties.Resources.back_undo_icon_circle_vector_260nw_3340805482;
            this.pictureBox7.Location = new System.Drawing.Point(57, 0);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(48, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 88;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label8.Font = new System.Drawing.Font("Segoe Print", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label8.Location = new System.Drawing.Point(996, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(167, 50);
            this.label8.TabIndex = 77;
            this.label8.Text = "ShareCare";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox6.Image = global::ShareCare.Properties.Resources._20440101;
            this.pictureBox6.Location = new System.Drawing.Point(840, 15);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(35, 35);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 65;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox5.Image = global::ShareCare.Properties.Resources._3642010;
            this.pictureBox5.Location = new System.Drawing.Point(653, 15);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(35, 35);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 64;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = global::ShareCare.Properties.Resources._25a8110514a47839265f640169ee27f51;
            this.pictureBox3.Location = new System.Drawing.Point(251, 15);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(35, 35);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 62;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Image = global::ShareCare.Properties.Resources.clients_icon_18;
            this.pictureBox4.Location = new System.Drawing.Point(452, 15);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(35, 35);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 63;
            this.pictureBox4.TabStop = false;
            // 
            // accountLastname
            // 
            this.accountLastname.AutoSize = true;
            this.accountLastname.Location = new System.Drawing.Point(441, 133);
            this.accountLastname.Name = "accountLastname";
            this.accountLastname.Size = new System.Drawing.Size(0, 17);
            this.accountLastname.TabIndex = 92;
            // 
            // uSERSBindingSource1
            // 
            this.uSERSBindingSource1.DataMember = "USERS";
            // 
            // accountFirstname
            // 
            this.accountFirstname.AutoSize = true;
            this.accountFirstname.Location = new System.Drawing.Point(441, 94);
            this.accountFirstname.Name = "accountFirstname";
            this.accountFirstname.Size = new System.Drawing.Size(0, 17);
            this.accountFirstname.TabIndex = 91;
            // 
            // accountUsername
            // 
            this.accountUsername.AutoSize = true;
            this.accountUsername.Location = new System.Drawing.Point(441, 43);
            this.accountUsername.Name = "accountUsername";
            this.accountUsername.Size = new System.Drawing.Size(0, 17);
            this.accountUsername.TabIndex = 90;
            // 
            // profileLastname
            // 
            this.profileLastname.AutoSize = true;
            this.profileLastname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileLastname.Location = new System.Drawing.Point(462, 127);
            this.profileLastname.Name = "profileLastname";
            this.profileLastname.Size = new System.Drawing.Size(0, 25);
            this.profileLastname.TabIndex = 89;
            // 
            // profileFirstname
            // 
            this.profileFirstname.AutoSize = true;
            this.profileFirstname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileFirstname.Location = new System.Drawing.Point(462, 88);
            this.profileFirstname.Name = "profileFirstname";
            this.profileFirstname.Size = new System.Drawing.Size(0, 25);
            this.profileFirstname.TabIndex = 88;
            // 
            // profileUsername
            // 
            this.profileUsername.AutoSize = true;
            this.profileUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileUsername.Location = new System.Drawing.Point(462, 43);
            this.profileUsername.Name = "profileUsername";
            this.profileUsername.Size = new System.Drawing.Size(0, 25);
            this.profileUsername.TabIndex = 87;
            // 
            // lastname
            // 
            this.lastname.AutoSize = true;
            this.lastname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastname.Location = new System.Drawing.Point(265, 127);
            this.lastname.Name = "lastname";
            this.lastname.Size = new System.Drawing.Size(138, 25);
            this.lastname.TabIndex = 86;
            this.lastname.Text = "LAST NAME :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Azure;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(121, 514);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(997, 257);
            this.dataGridView1.TabIndex = 93;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(116, 477);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 25);
            this.label7.TabIndex = 89;
            this.label7.Text = "My Posts";
            // 
            // uSERSTableAdapter1
            // 
            this.uSERSTableAdapter1.ClearBeforeFill = true;
            // 
            // userName
            // 
            this.userName.AutoSize = true;
            this.userName.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userName.Location = new System.Drawing.Point(263, 153);
            this.userName.Name = "userName";
            this.userName.Size = new System.Drawing.Size(0, 36);
            this.userName.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ShareCare.Properties.Resources.default_avatar_profile_icon_vector_default_avatar_profile_icon_vector_social_media_user_image_vector_illustration_2277872272;
            this.pictureBox1.Location = new System.Drawing.Point(73, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(173, 161);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // user
            // 
            this.user.AutoSize = true;
            this.user.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user.Location = new System.Drawing.Point(265, 43);
            this.user.Name = "user";
            this.user.Size = new System.Drawing.Size(82, 25);
            this.user.TabIndex = 78;
            this.user.Text = "USER : ";
            // 
            // uSERSTableAdapter
            // 
            this.uSERSTableAdapter.ClearBeforeFill = true;
            // 
            // sHARECAREDataSet3
            // 
            this.sHARECAREDataSet3.DataSetName = "SHARECAREDataSet3";
            this.sHARECAREDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // uSERSBindingSource2
            // 
            this.uSERSBindingSource2.DataMember = "USERS";
            this.uSERSBindingSource2.DataSource = this.sHARECAREDataSet3;
            // 
            // firstname
            // 
            this.firstname.AutoSize = true;
            this.firstname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstname.Location = new System.Drawing.Point(265, 88);
            this.firstname.Name = "firstname";
            this.firstname.Size = new System.Drawing.Size(143, 25);
            this.firstname.TabIndex = 85;
            this.firstname.Text = "FIRST NAME :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(341, 29);
            this.label1.TabIndex = 68;
            this.label1.Text = "Share to make the world better";
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(884, 66);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(76, 32);
            this.button3.TabIndex = 65;
            this.button3.Text = "Post";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label2.Location = new System.Drawing.Point(3, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 26);
            this.label2.TabIndex = 63;
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(29, 55);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(831, 50);
            this.textBox1.TabIndex = 64;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.button3);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.textBox1);
            this.panel6.Location = new System.Drawing.Point(92, 330);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1027, 135);
            this.panel6.TabIndex = 91;
            // 
            // uSERSBindingSource
            // 
            this.uSERSBindingSource.DataMember = "USERS";
            this.uSERSBindingSource.DataSource = this.sHARECAREDataSet;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(245)))));
            this.panel2.Controls.Add(this.accountLastname);
            this.panel2.Controls.Add(this.accountFirstname);
            this.panel2.Controls.Add(this.accountUsername);
            this.panel2.Controls.Add(this.profileLastname);
            this.panel2.Controls.Add(this.profileFirstname);
            this.panel2.Controls.Add(this.profileUsername);
            this.panel2.Controls.Add(this.lastname);
            this.panel2.Controls.Add(this.userName);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.user);
            this.panel2.Controls.Add(this.firstname);
            this.panel2.Location = new System.Drawing.Point(-28, 75);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1147, 250);
            this.panel2.TabIndex = 92;
            // 
            // AcountCreated
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(249)))), ((int)(((byte)(245)))));
            this.ClientSize = new System.Drawing.Size(1192, 798);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel2);
            this.Name = "AcountCreated";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MyProfile";
            this.Load += new System.EventHandler(this.AcountCreated_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sHARECAREDataSet)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSERSBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sHARECAREDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uSERSBindingSource2)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uSERSBindingSource)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SHARECAREDataSet sHARECAREDataSet;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label accountLastname;
        private System.Windows.Forms.BindingSource uSERSBindingSource1;
        private System.Windows.Forms.Label accountFirstname;
        private System.Windows.Forms.Label accountUsername;
        private System.Windows.Forms.Label profileLastname;
        private System.Windows.Forms.Label profileFirstname;
        private System.Windows.Forms.Label profileUsername;
        private System.Windows.Forms.Label lastname;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label7;
        private SHARECAREDataSet3TableAdapters.USERSTableAdapter uSERSTableAdapter1;
        private System.Windows.Forms.Label userName;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label user;
        private SHARECAREDataSetTableAdapters.USERSTableAdapter uSERSTableAdapter;
        private SHARECAREDataSet3 sHARECAREDataSet3;
        private System.Windows.Forms.BindingSource uSERSBindingSource2;
        private System.Windows.Forms.Label firstname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.BindingSource uSERSBindingSource;
        private System.Windows.Forms.Panel panel2;
    }
}