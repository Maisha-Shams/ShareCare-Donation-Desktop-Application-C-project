﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShareCare
{
    public partial class PaymentOptions : Form
    {
        public PaymentOptions()
        {
            InitializeComponent();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();
            Help help = new Help();
            help.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Donation d = new Donation();
            d.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Donation d = new Donation();
            d.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Donation d = new Donation();
            d.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Donation d = new Donation();
            d.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Donation d = new Donation();
            d.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Donation d = new Donation();
            d.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Donation d = new Donation();
            d.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Donation d = new Donation();
            d.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Donation d = new Donation();
            d.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            Donation d = new Donation();
            d.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();
            Donation d = new Donation();
            d.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();
            Donation d = new Donation();
            d.Show();
        }

        private void PaymentOptions_Load(object sender, EventArgs e)
        {

        }
    }
}
